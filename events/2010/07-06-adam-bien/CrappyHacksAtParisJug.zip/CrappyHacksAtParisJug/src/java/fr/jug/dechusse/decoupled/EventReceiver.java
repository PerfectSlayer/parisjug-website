/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.jug.dechusse.decoupled;

import javax.ejb.Stateless;
import javax.enterprise.event.Observes;

/**
 *
 * @author abien
 */
@Stateless
public class EventReceiver {


    public void onHelloParis(@Observes String message){
        System.out.println("----------- " + message);
    }
}
