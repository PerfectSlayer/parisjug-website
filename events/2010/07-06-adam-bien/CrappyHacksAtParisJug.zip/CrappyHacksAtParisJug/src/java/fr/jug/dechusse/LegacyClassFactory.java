/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.jug.dechusse;

import javax.ejb.Stateless;
import javax.enterprise.inject.Produces;

/**
 *
 * @author abien
 */
@Stateless
public class LegacyClassFactory {

    @Produces
    public TotallyLegacy create(){
        return new TotallyLegacy("from legacy factory");
    }
}
