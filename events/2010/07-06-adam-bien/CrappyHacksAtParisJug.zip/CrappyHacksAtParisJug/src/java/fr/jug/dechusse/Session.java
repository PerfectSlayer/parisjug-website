/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.jug.dechusse;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author abien
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Session {

    private String name;

    public Session(String name) {
        this.name = name;
    }

    public Session() {
    }

    
}
