package fr.jug.dechusse;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.hibernate.validator.constraints.Email;

/**
 * female duke
 * @author abien
 */
@Path("session")
@Stateless
@Interceptors(CrossCutter.class)
@LocalBean
@Named
public class ParisJugService {

    @EJB
    Messenger messenger;

    @Resource
    SessionContext sc;

    @PersistenceContext
    EntityManager em;

    @Inject
    TotallyLegacy tl;

    @Inject
    Event<String> event;

    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public Session helloParis(){
        System.out.println("Hello Paris");
        messenger.audit("something " + sc.getCallerPrincipal());
        em.persist(new SessionEntity("hopefuly works"));
        event.fire("hello Paris invoked!");
        return new Session(messenger.message() + " " + tl.hello() );
    }

    @POST
    @Consumes("text/plain")
    public void save(String message){
        System.out.println("Saved! " + message);
    }

    public void hello(){
        System.out.println("Hello ");
    }

}
