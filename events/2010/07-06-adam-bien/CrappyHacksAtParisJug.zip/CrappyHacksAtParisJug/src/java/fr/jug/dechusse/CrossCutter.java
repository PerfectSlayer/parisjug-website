/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.jug.dechusse;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author abien
 */
public class CrossCutter {

    @AroundInvoke
    public Object cutMe(InvocationContext context) throws Exception{
        System.out.println("--- " + context.getMethod());
        return context.proceed();
    }

}
