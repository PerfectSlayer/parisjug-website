/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.jug.dechusse;

/**
 *
 * @author abien
 */
public class TotallyLegacy {

    private String message;

    public TotallyLegacy(String message) {
        this.message = message;
    }



    public String hello(){
        return "hello from legacy";
    }

}
