/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fr.jug.dechusse;

import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;

/**
 *
 * @author abien
 */
@Stateless
public class Messenger {

        public String message(){
            return "hello paris" + System.currentTimeMillis();
        }

        @Asynchronous
        public Future<String> audit(String message){
        try {
            Thread.sleep(2000);
            System.out.println(" Audit: " + message);
        } catch (InterruptedException ex) {
            Logger.getLogger(Messenger.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<String>("Done!");
        }
}
