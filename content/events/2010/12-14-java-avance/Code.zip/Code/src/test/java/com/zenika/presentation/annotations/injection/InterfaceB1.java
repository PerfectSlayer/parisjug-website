package com.zenika.presentation.annotations.injection;

@AnnotationB("foo")
public interface InterfaceB1 {
}
