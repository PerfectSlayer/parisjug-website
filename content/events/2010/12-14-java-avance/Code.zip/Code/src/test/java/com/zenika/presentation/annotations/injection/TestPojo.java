package com.zenika.presentation.annotations.injection;

/**
 * @author Olivier Croisier
 * @version $Id: TestPojo.java 1921 2010-12-13 10:07:01Z OlivierCroisier $
 */
public class TestPojo {

    private String foo;

}
