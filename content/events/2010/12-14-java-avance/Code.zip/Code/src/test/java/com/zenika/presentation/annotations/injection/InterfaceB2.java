package com.zenika.presentation.annotations.injection;

@AnnotationB("bar")
public interface InterfaceB2 {
}
