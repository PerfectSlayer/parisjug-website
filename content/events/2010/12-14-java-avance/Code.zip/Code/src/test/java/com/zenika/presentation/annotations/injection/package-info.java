@AnnotationB("bar")
package com.zenika.presentation.annotations.injection;