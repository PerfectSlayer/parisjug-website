package com.zenika.presentation.annotations.injection;

@AnnotationA
@NonInheritableAnnotation
public interface InterfaceA1 {
}
