package com.zenika.presentation.annotations.injection;

@AnnotationA
public interface InterfaceA2 {
}
