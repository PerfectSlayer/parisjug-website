package com.zenika.presentation.annotations.compilation.serializable.test;

import java.io.Serializable;

public class Pojo2 implements Serializable {
}
