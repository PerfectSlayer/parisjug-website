@SerializableClasses
package com.zenika.presentation.annotations.compilation.serializable.test;

import com.zenika.presentation.annotations.compilation.serializable.SerializableClasses;