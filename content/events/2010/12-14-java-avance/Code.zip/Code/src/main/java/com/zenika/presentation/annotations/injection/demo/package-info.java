@MyAnnotation(message = "Hello Paris JUG")
package com.zenika.presentation.annotations.injection.demo;