package com.zenika.presentation.annotations.compilation.serializable.test;


public class Pojo1 {
}
