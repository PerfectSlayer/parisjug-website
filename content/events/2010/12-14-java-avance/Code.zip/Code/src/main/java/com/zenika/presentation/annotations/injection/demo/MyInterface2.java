package com.zenika.presentation.annotations.injection.demo;

@MyAnnotation(message="un autre message")
public interface MyInterface2 {
}
