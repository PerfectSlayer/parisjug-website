package com.zenika.presentation.annotations.presentation;

/**
 * @author Olivier Croisier
 * @version $Id: Superclass.java 1921 2010-12-13 10:07:01Z OlivierCroisier $
 */
public class Superclass {

    public void overridenMethod() {
    }

}
