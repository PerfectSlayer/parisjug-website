package com.zenika.presentation.annotations.injection.demo;

@MyAnnotation
public interface MyInterface {
}
