package com.zenika.presentation.annotations.presentation;

public class PojoAnnotation extends Superclass {

    @Override
    public void overridenMethod() {
        super.overridenMethod();
    }

    @Deprecated
    public void oldMethod() {
    }

}