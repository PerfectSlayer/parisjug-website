package com.zenika.presentation.annotations.modeemploi;

@
/**
 *  Hello
 */
SuppressWarnings("all")
public class Pojo {

    @Deprecated
    private int foo;

    @Deprecated
    public Pojo() {

        @Deprecated
        int localVar = 0;

    }

    @Deprecated
    public int getFoo() {
        return foo;
    }

    public void setFoo(@Deprecated int foo) {
        this.foo = foo;
    }
}
