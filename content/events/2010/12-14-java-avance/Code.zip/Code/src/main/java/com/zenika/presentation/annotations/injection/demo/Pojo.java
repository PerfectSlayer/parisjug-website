package com.zenika.presentation.annotations.injection.demo;

public class Pojo implements MyInterface, MyInterface2 {
}
